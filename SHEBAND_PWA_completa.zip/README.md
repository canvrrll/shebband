# SHEBAND PWA

PWA de SHEBAND, estética rosa/aesthetic.

## Incluye
- instalación en pantalla de inicio;
- funcionamiento como app independiente;
- caché offline de la interfaz;
- reloj;
- perfil local;
- contactos autorizados;
- botón de emergencia de 3 segundos;
- geolocalización cuando el navegador la permite;
- historial local;
- sección informativa con carrusel;
- íconos PWA.

## Cómo publicarla
Subí el contenido de esta carpeta a la raíz de un hosting con HTTPS.

Para iPhone:
Safari → abrir la URL → Compartir → Agregar a pantalla de inicio.

## Limitación importante
Offline no significa que pueda enviar una alerta a otra persona sin red. La PWA puede abrirse y guardar la alerta localmente sin Internet; para transmitirla hace falta una conexión disponible. Para alertas reales a terceros hay que agregar backend, base de datos y un canal de notificación/SMS.
