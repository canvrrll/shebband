const CACHE="sheband-pwa-v1";
const APP="./";
const ASSETS=["./","./index.html","./manifest.webmanifest","./icons/icon-192.png","./icons/icon-512.png"];
self.addEventListener("install",event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",event=>event.waitUntil(self.clients.claim()));
self.addEventListener("fetch",event=>{
  if(event.request.method!=="GET") return;
  event.respondWith(caches.match(event.request).then(cached=>{
    const network=fetch(event.request).then(response=>{
      if(response.ok && new URL(event.request.url).origin===location.origin){
        const copy=response.clone(); caches.open(CACHE).then(c=>c.put(event.request,copy));
      }
      return response;
    }).catch(()=>cached);
    return cached || network;
  }));
});